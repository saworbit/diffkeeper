//go:build integration
// +build integration

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/saworbit/diffkeeper/pkg/config"
)

// TestDiffChain20Plus tests binary diff chains with 25+ versions
// This validates FR1: Diff Reconstruction requirement
func TestDiffChain20Plus(t *testing.T) {
	tmpDir := t.TempDir()
	stateDir := filepath.Join(tmpDir, "state")
	storePath := filepath.Join(tmpDir, "store.db")

	if err := os.MkdirAll(stateDir, 0755); err != nil {
		t.Fatalf("Failed to create state dir: %v", err)
	}

	// Configure with snapshot interval of 10
	cfg := config.DefaultConfig()
	cfg.EnableDiff = true
	cfg.SnapshotInterval = 10

	dk, err := NewDiffKeeper(stateDir, storePath, cfg)
	if err != nil {
		t.Fatalf("Failed to create DiffKeeper: %v", err)
	}
	defer dk.Close()

	testFile := filepath.Join(stateDir, "longchain.txt")

	// Create 25 versions with incremental changes
	versions := make([][]byte, 25)
	for i := 0; i < 25; i++ {
		// Append new data to simulate incremental changes
		content := fmt.Sprintf("Version %d\n", i+1)
		for j := 0; j <= i; j++ {
			content += fmt.Sprintf("Line %d of version %d\n", j, i+1)
		}
		versions[i] = []byte(content)

		if err := os.WriteFile(testFile, versions[i], 0644); err != nil {
			t.Fatalf("Failed to write version %d: %v", i+1, err)
		}

		if err := dk.BlueShift(testFile); err != nil {
			t.Fatalf("Failed to capture version %d: %v", i+1, err)
		}

		t.Logf("Captured version %d (%d bytes)", i+1, len(versions[i]))
	}

	// Verify metadata for the final version
	meta, err := dk.getMetadata("longchain.txt")
	if err != nil {
		t.Fatalf("Failed to get metadata: %v", err)
	}

	// Check version count
	if meta.VersionCount != 25 {
		t.Errorf("Expected version count 25, got %d", meta.VersionCount)
	}

	// Versions 10 and 20 should have been snapshots
	// Version 25 should be a diff
	if meta.IsSnapshot {
		t.Logf("Version 25 is a snapshot (expected diff)")
	}

	// Verify BaseSnapshotCID is set
	if meta.BaseSnapshotCID == "" {
		t.Errorf("Expected BaseSnapshotCID to be set, got empty string")
	}

	t.Logf("Final version: VersionCount=%d, IsSnapshot=%v, BaseSnapshotCID=%s",
		meta.VersionCount, meta.IsSnapshot, meta.BaseSnapshotCID[:16])

	// Test recovery - reconstruct the file
	if err := os.Remove(testFile); err != nil {
		t.Fatalf("Failed to remove test file: %v", err)
	}

	if err := dk.RedShift(); err != nil {
		t.Fatalf("Failed to recover file: %v", err)
	}

	// Verify reconstructed content matches version 25
	recovered, err := os.ReadFile(testFile)
	if err != nil {
		t.Fatalf("Failed to read recovered file: %v", err)
	}

	if string(recovered) != string(versions[24]) {
		t.Errorf("Reconstructed content doesn't match version 25")
		t.Logf("Expected length: %d, got: %d", len(versions[24]), len(recovered))
		t.Logf("Expected: %s...", string(versions[24][:min(100, len(versions[24]))]))
		t.Logf("Got: %s...", string(recovered[:min(100, len(recovered))]))
	}

	t.Logf("âœ… Diff chain test passed (25 versions, 3 snapshots at v1/v10/v20)")
}

// TestDiffChainStorageSavings measures storage efficiency with diff chains
func TestDiffChainStorageSavings(t *testing.T) {
	tmpDir := t.TempDir()
	stateDir := filepath.Join(tmpDir, "state")
	storePath := filepath.Join(tmpDir, "store.db")

	if err := os.MkdirAll(stateDir, 0755); err != nil {
		t.Fatalf("Failed to create state dir: %v", err)
	}

	// Test with binary diffs enabled
	cfg := config.DefaultConfig()
	cfg.EnableDiff = true
	cfg.SnapshotInterval = 10

	dk, err := NewDiffKeeper(stateDir, storePath, cfg)
	if err != nil {
		t.Fatalf("Failed to create DiffKeeper: %v", err)
	}
	defer dk.Close()

	testFile := filepath.Join(stateDir, "savings.dat")

	// Create a 1MB base file
	baseData := make([]byte, 1024*1024) // 1MB
	for i := range baseData {
		baseData[i] = byte(i)
	}

	// Write initial version
	if err := os.WriteFile(testFile, baseData, 0644); err != nil {
		t.Fatalf("Failed to write base file: %v", err)
	}
	if err := dk.BlueShift(testFile); err != nil {
		t.Fatalf("Failed to capture base: %v", err)
	}

	// Create 20 versions with 10% changes each
	totalOriginalSize := int64(len(baseData))
	for i := 0; i < 20; i++ {
		// Modify 10% of the data (100KB)
		modifyStart := (i * 102400) % len(baseData)
		modifyEnd := modifyStart + 102400
		if modifyEnd > len(baseData) {
			modifyEnd = len(baseData)
		}

		for j := modifyStart; j < modifyEnd; j++ {
			baseData[j] = byte(baseData[j] + 1)
		}

		if err := os.WriteFile(testFile, baseData, 0644); err != nil {
			t.Fatalf("Failed to write version %d: %v", i+2, err)
		}
		if err := dk.BlueShift(testFile); err != nil {
			t.Fatalf("Failed to capture version %d: %v", i+2, err)
		}

		totalOriginalSize += int64(len(baseData))
	}

	// Calculate total storage used
	stats, err := dk.cas.GetStats()
	if err != nil {
		t.Fatalf("Failed to get CAS stats: %v", err)
	}

	totalStorageUsed := stats.TotalSize
	savingsPercent := (1.0 - float64(totalStorageUsed)/float64(totalOriginalSize)) * 100

	t.Logf("Total original size: %.2f MB (%d bytes)", float64(totalOriginalSize)/1024/1024, totalOriginalSize)
	t.Logf("Total storage used: %.2f MB (%d bytes)", float64(totalStorageUsed)/1024/1024, totalStorageUsed)
	t.Logf("Storage savings: %.1f%%", savingsPercent)
	t.Logf("CAS objects: %d", stats.TotalObjects)

	// We expect significant savings with binary diffs
	// With 21 versions of 1MB each, full snapshots would be ~21MB
	// With diffs (10% changes), we expect < 5MB total storage
	if savingsPercent < 30 {
		t.Logf("Warning: Storage savings (%.1f%%) less than expected (>30%%)", savingsPercent)
	}

	t.Logf("âœ… Storage savings test complete")
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
